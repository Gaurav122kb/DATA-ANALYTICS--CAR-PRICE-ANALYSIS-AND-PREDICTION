import { Brand, CarData, FuelType, Transmission, PredictionInput, FeatureImportance, DepreciationPoint, Owner, Insurance, CarModelInfo } from '../types';

// Detailed Database derived from user provided table
export const CAR_DATABASE: Record<Brand, CarModelInfo[]> = {
  [Brand.MarutiSuzuki]: [
    { name: "Baleno", releaseYear: 2015, country: "India", basePrice: 850000, bodyType: "Hatchback" },
    { name: "Swift DZire", releaseYear: 2017, country: "India", basePrice: 950000, bodyType: "Sedan" },
    { name: "XL6", releaseYear: 2019, country: "India", basePrice: 1400000, bodyType: "MPV" }
  ],
  [Brand.TataMotors]: [
    { name: "Nexon", releaseYear: 2017, country: "India", basePrice: 1200000, bodyType: "SUV" },
    { name: "Harrier", releaseYear: 2019, country: "India", basePrice: 2200000, bodyType: "SUV" },
    { name: "Punch", releaseYear: 2021, country: "India", basePrice: 900000, bodyType: "Compact SUV" }
  ],
  [Brand.Mahindra]: [
    { name: "XUV300", releaseYear: 2019, country: "India", basePrice: 1300000, bodyType: "SUV" },
    { name: "Thar", releaseYear: 2020, country: "India", basePrice: 1700000, bodyType: "SUV" },
    { name: "Scorpio N", releaseYear: 2022, country: "India", basePrice: 2400000, bodyType: "SUV" }
  ],
  [Brand.Hyundai]: [
    { name: "Creta", releaseYear: 2015, country: "South Korea", basePrice: 1600000, bodyType: "SUV" },
    { name: "Venue", releaseYear: 2019, country: "South Korea", basePrice: 1100000, bodyType: "Compact SUV" },
    { name: "Ioniq 5", releaseYear: 2022, country: "South Korea", basePrice: 4500000, bodyType: "EV" }
  ],
  [Brand.Kia]: [
    { name: "Seltos", releaseYear: 2019, country: "South Korea", basePrice: 1600000, bodyType: "SUV" },
    { name: "Sonet", releaseYear: 2020, country: "South Korea", basePrice: 1100000, bodyType: "Compact SUV" },
    { name: "EV6", releaseYear: 2022, country: "South Korea", basePrice: 6000000, bodyType: "EV" }
  ],
  [Brand.Toyota]: [
    { name: "Innova Crysta", releaseYear: 2016, country: "Japan", basePrice: 2600000, bodyType: "MPV" },
    { name: "Urban Cruiser", releaseYear: 2020, country: "Japan", basePrice: 1100000, bodyType: "Compact SUV" },
    { name: "bZ4X", releaseYear: 2022, country: "Japan", basePrice: 5000000, bodyType: "EV" }
  ],
  [Brand.Honda]: [
    { name: "City", releaseYear: 2016, country: "Japan", basePrice: 1500000, bodyType: "Sedan" },
    { name: "Amaze", releaseYear: 2018, country: "Japan", basePrice: 900000, bodyType: "Sedan" },
    { name: "Elevate", releaseYear: 2023, country: "Japan", basePrice: 1600000, bodyType: "SUV" }
  ],
  [Brand.Ford]: [
    { name: "EcoSport", releaseYear: 2018, country: "USA", basePrice: 1100000, bodyType: "Compact SUV" },
    { name: "Mustang Mach-E", releaseYear: 2021, country: "USA", basePrice: 7000000, bodyType: "EV" },
    { name: "F-150 Lightning", releaseYear: 2022, country: "USA", basePrice: 8000000, bodyType: "Pickup" }
  ],
  [Brand.BMW]: [
    { name: "X1", releaseYear: 2016, country: "Germany", basePrice: 4800000, bodyType: "SUV" },
    { name: "iX", releaseYear: 2021, country: "Germany", basePrice: 12000000, bodyType: "EV" },
    { name: "5 Series", releaseYear: 2023, country: "Germany", basePrice: 7000000, bodyType: "Sedan" }
  ],
  [Brand.MercedesBenz]: [
    { name: "A-Class", releaseYear: 2018, country: "Germany", basePrice: 4500000, bodyType: "Hatchback" },
    { name: "EQS", releaseYear: 2021, country: "Germany", basePrice: 16000000, bodyType: "EV" }
  ]
};

const FUEL_MULTIPLIER: Record<FuelType, number> = {
  [FuelType.Petrol]: 1.0,
  [FuelType.Diesel]: 1.15,
  [FuelType.Electric]: 1.3,
};

const TRANSMISSION_MULTIPLIER: Record<Transmission, number> = {
  [Transmission.Manual]: 1.0,
  [Transmission.Automatic]: 1.15,
};

const OWNER_MULTIPLIER: Record<Owner, number> = {
  [Owner.First]: 1.0,
  [Owner.Second]: 0.9,
  [Owner.Third]: 0.8,
  [Owner.FourthPlus]: 0.7,
};

const INSURANCE_ADDER: Record<Insurance, number> = {
  [Insurance.Comprehensive]: 15000,
  [Insurance.ThirdParty]: 5000,
  [Insurance.Expired]: -10000,
  [Insurance.None]: -20000,
};

const DEPRECIATION_RATE = 0.09; // Slightly higher
const BASE_KM_DEPRECIATION = 2.5;
const RTO_LIST = ["Delhi", "Mumbai", "Bangalore", "Chennai", "Hyderabad", "Pune", "Kolkata", "Ahmedabad"];

// Generate Synthetic Data using the specific models
export const generateSyntheticData = (count: number = 500): CarData[] => {
  const data: CarData[] = [];
  const brands = Object.values(Brand);
  const fuels = Object.values(FuelType);
  const transmissions = Object.values(Transmission);
  const owners = Object.values(Owner);
  const insurances = Object.values(Insurance);

  for (let i = 0; i < count; i++) {
    const brand = brands[Math.floor(Math.random() * brands.length)];
    // Pick a random model from that brand
    const availableModels = CAR_DATABASE[brand];
    const modelInfo = availableModels[Math.floor(Math.random() * availableModels.length)];

    // Ensure random year is >= release year
    const minYear = modelInfo.releaseYear;
    const year = Math.floor(Math.random() * (2025 - minYear + 1)) + minYear;
    
    const kmsDriven = Math.floor(Math.random() * (150000 - 5000 + 1)) + 5000;
    
    // Bias logic: EVs usually Automatic, etc.
    let fuelType = fuels[Math.floor(Math.random() * fuels.length)];
    if (modelInfo.basePrice > 4000000 && Math.random() > 0.3) fuelType = FuelType.Electric; // Expensive cars often EV in this list (iX, EQS)
    if (modelInfo.name.includes("EV") || modelInfo.name.includes("Ioniq") || modelInfo.name.includes("bZ4X") || modelInfo.name.includes("Mach-E") || modelInfo.name.includes("Lightning")) {
        fuelType = FuelType.Electric;
    }
    
    let transmission = transmissions[Math.floor(Math.random() * transmissions.length)];
    if (fuelType === FuelType.Electric) transmission = Transmission.Automatic;

    const owner = owners[Math.floor(Math.random() * owners.length)];
    const insurance = insurances[Math.floor(Math.random() * insurances.length)];
    const rto = RTO_LIST[Math.floor(Math.random() * RTO_LIST.length)];
    const seats = ["XL6", "Innova Crysta", "Scorpio N", "XUV300"].includes(modelInfo.name) ? 7 : 5;
    
    let baseCC = 1200;
    if (brand === Brand.BMW || brand === Brand.MercedesBenz) baseCC = 2000;
    if (modelInfo.bodyType === "SUV") baseCC += 500;
    const engineCC = fuelType === FuelType.Electric ? 0 : baseCC + Math.floor(Math.random() * 500);

    const input: PredictionInput = { 
      brand, model: modelInfo.name, year, kmsDriven, fuelType, transmission, owner, insurance, rto, seats, engineCC 
    };

    const price = calculateHeuristicPrice(input);
    const noise = (Math.random() - 0.5) * 0.1 * price;

    data.push({
      id: i,
      ...input,
      price: Math.max(50000, Math.floor(price + noise)),
    });
  }
  return data;
};

export const calculateHeuristicPrice = (input: PredictionInput): number => {
  // Find model info for base price
  const modelModels = CAR_DATABASE[input.brand];
  const modelInfo = modelModels.find(m => m.name === input.model) || modelModels[0];

  let price = modelInfo.basePrice;

  // Adjust by Engine CC only if not electric
  if (input.fuelType !== FuelType.Electric) {
    price += (input.engineCC * 150); 
  }

  // Apply Year Depreciation (Standard method)
  // Ensure we don't punish 'new' cars too much if the 'year' is close to 2025
  const age = 2025 - input.year;
  price = price * Math.pow(1 - DEPRECIATION_RATE, age);

  // Apply Km Depreciation
  const luxuryFactor = (modelInfo.basePrice > 3000000) ? 5 : 1.5;
  price = price - (input.kmsDriven * BASE_KM_DEPRECIATION * luxuryFactor);

  // Apply Modifiers
  price = price * FUEL_MULTIPLIER[input.fuelType];
  price = price * TRANSMISSION_MULTIPLIER[input.transmission];
  price = price * OWNER_MULTIPLIER[input.owner];

  if (input.seats > 5) price *= 1.05;
  price += INSURANCE_ADDER[input.insurance];

  return Math.max(50000, Math.floor(price));
};

export const getDepreciationTrend = (input: PredictionInput): DepreciationPoint[] => {
  const trend: DepreciationPoint[] = [];
  const modelModels = CAR_DATABASE[input.brand];
  const modelInfo = modelModels.find(m => m.name === input.model) || modelModels[0];
  
  for (let i = 0; i <= 5; i++) {
    const futureAge = (2025 - input.year) + i;
    const futureKms = input.kmsDriven + (i * 15000); 
    
    let futurePrice = modelInfo.basePrice;
    if (input.fuelType !== FuelType.Electric) futurePrice += (input.engineCC * 150);
    
    futurePrice = futurePrice * Math.pow(1 - DEPRECIATION_RATE, futureAge);
    
    const luxuryFactor = (modelInfo.basePrice > 3000000) ? 5 : 1.5;
    futurePrice = futurePrice - (futureKms * BASE_KM_DEPRECIATION * luxuryFactor);
    
    futurePrice = futurePrice * FUEL_MULTIPLIER[input.fuelType];
    futurePrice = futurePrice * TRANSMISSION_MULTIPLIER[input.transmission];
    futurePrice = futurePrice * OWNER_MULTIPLIER[input.owner];
    if (input.seats > 5) futurePrice *= 1.05;

    trend.push({
      year: `+${i} Year${i === 1 ? '' : 's'}`,
      price: Math.max(0, Math.floor(futurePrice))
    });
  }
  return trend;
};

export const getFeatureImportance = (): FeatureImportance[] => {
  return [
    { feature: 'Model Baseline', importance: 0.40 },
    { feature: 'Year of Manufacture', importance: 0.30 },
    { feature: 'Kilometers Driven', importance: 0.10 },
    { feature: 'Engine/Power', importance: 0.08 },
    { feature: 'Fuel Type', importance: 0.05 },
    { feature: 'Ownership History', importance: 0.05 },
    { feature: 'Transmission', importance: 0.02 },
  ];
};