import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Brand, FuelType, Transmission, PredictionInput, CarData, FeatureImportance, DepreciationPoint, Owner, Insurance } from './types';
import { generateSyntheticData, calculateHeuristicPrice, getDepreciationTrend, getFeatureImportance } from './services/carService';

const App: React.FC = () => {
  // State for user inputs
  const [inputs, setInputs] = useState<PredictionInput>({
    brand: Brand.MarutiSuzuki,
    model: "Baleno",
    year: 2020,
    kmsDriven: 45000,
    fuelType: FuelType.Petrol,
    transmission: Transmission.Manual,
    owner: Owner.First,
    engineCC: 1197,
    seats: 5,
    rto: "Delhi",
    insurance: Insurance.Comprehensive,
  });

  // State for application data
  const [marketData, setMarketData] = useState<CarData[]>([]);
  const [predictedPrice, setPredictedPrice] = useState<number | null>(null);
  const [currentCar, setCurrentCar] = useState<CarData | null>(null);
  const [depreciationTrend, setDepreciationTrend] = useState<DepreciationPoint[]>([]);
  const [featureImportance, setFeatureImportance] = useState<FeatureImportance[]>([]);
  
  // Loading state (mimicking ML model load)
  const [isDataLoading, setIsDataLoading] = useState(true);

  // Initialize Synthetic Data on Mount
  useEffect(() => {
    // Simulate async data loading
    const timer = setTimeout(() => {
      const data = generateSyntheticData(500);
      setMarketData(data);
      setIsDataLoading(false);
    }, 800);

    return () => clearTimeout(timer);
  }, []);

  const handlePredict = () => {
    // Calculate Price
    const price = calculateHeuristicPrice(inputs);
    setPredictedPrice(price);

    // Create a "CarData" object for the current user input to visualize
    const userCar: CarData = {
      id: 9999, // dummy ID
      ...inputs,
      price: price
    };
    setCurrentCar(userCar);

    // Calculate Analytics
    setDepreciationTrend(getDepreciationTrend(inputs));
    setFeatureImportance(getFeatureImportance());
  };

  if (isDataLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
        <h2 className="text-gray-600 font-medium animate-pulse">Training ML Model on Synthetic Data...</h2>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-gray-100 font-sans">
      
      {/* Sidebar for Desktop */}
      <div className="hidden lg:block h-full">
        <Sidebar 
          inputs={inputs} 
          setInputs={setInputs} 
          onPredict={handlePredict} 
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        
        {/* Mobile Header / Nav could go here if needed */}
        
        {/* Dashboard Area */}
        <Dashboard 
          predictedPrice={predictedPrice}
          marketData={marketData}
          currentCar={currentCar}
          depreciationTrend={depreciationTrend}
          featureImportance={featureImportance}
        />
        
        {/* Mobile Sidebar (Simplified as a bottom sheet or toggle in real app, but using simple absolute positioning for this demo if screen is small) */}
        <div className="lg:hidden absolute bottom-4 right-4 z-50">
           {/* In a full responsive app, we'd add a toggle button here to show the sidebar modal */}
        </div>
      </div>
    </div>
  );
};

export default App;