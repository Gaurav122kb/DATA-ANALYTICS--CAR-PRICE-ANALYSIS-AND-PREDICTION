export enum Brand {
  MarutiSuzuki = 'Maruti Suzuki',
  TataMotors = 'Tata Motors',
  Mahindra = 'Mahindra',
  Hyundai = 'Hyundai',
  Kia = 'Kia',
  Toyota = 'Toyota',
  Honda = 'Honda',
  Ford = 'Ford',
  BMW = 'BMW',
  MercedesBenz = 'Mercedes-Benz',
}

export enum FuelType {
  Petrol = 'Petrol',
  Diesel = 'Diesel',
  Electric = 'Electric',
}

export enum Transmission {
  Manual = 'Manual',
  Automatic = 'Automatic',
}

export enum Owner {
  First = 'First Owner',
  Second = 'Second Owner',
  Third = 'Third Owner',
  FourthPlus = 'Fourth+ Owner',
}

export enum Insurance {
  Comprehensive = 'Comprehensive',
  ThirdParty = 'Third Party',
  Expired = 'Expired',
  None = '-',
}

export interface CarData {
  id: number;
  brand: Brand;
  model: string;
  year: number;
  kmsDriven: number;
  fuelType: FuelType;
  transmission: Transmission;
  price: number;
  owner: Owner;
  engineCC: number;
  seats: number;
  rto: string;
  insurance: Insurance;
}

export interface PredictionInput {
  brand: Brand;
  model: string;
  year: number;
  kmsDriven: number;
  fuelType: FuelType;
  transmission: Transmission;
  owner: Owner;
  engineCC: number;
  seats: number;
  rto: string;
  insurance: Insurance;
}

export interface FeatureImportance {
  feature: string;
  importance: number;
}

export interface DepreciationPoint {
  year: string;
  price: number;
}

// Helper interface for our database
export interface CarModelInfo {
  name: string;
  releaseYear: number;
  country: string;
  basePrice: number;
  bodyType: string;
}