import React, { useMemo } from 'react';
import { 
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, BarChart, Bar, Cell, Legend
} from 'recharts';
import { CarData, DepreciationPoint, FeatureImportance } from '../types';
import { TrendingDown, BarChart3, LineChart as LineIcon, Calendar, Shield, Fuel, Armchair, Gauge, Building2, User, Link, GitGraph, Clock, Car } from 'lucide-react';

interface DashboardProps {
  predictedPrice: number | null;
  marketData: CarData[];
  currentCar: CarData | null;
  depreciationTrend: DepreciationPoint[];
  featureImportance: FeatureImportance[];
}

export const Dashboard: React.FC<DashboardProps> = ({ 
  predictedPrice, 
  marketData, 
  currentCar,
  depreciationTrend,
  featureImportance
}) => {

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const filteredMarketData = useMemo(() => {
    if(!currentCar) return [];
    // Filter by Brand, but also boost visibility of specific Model if available in synthetic data
    return marketData.filter(car => car.brand === currentCar.brand);
  }, [marketData, currentCar]);

  if (!currentCar || predictedPrice === null) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-50 p-10 text-center">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 max-w-md">
          <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">👈</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Ready to Analyze</h2>
          <p className="text-gray-500">
            Adjust the vehicle configuration in the sidebar and click 
            <span className="font-semibold text-indigo-600 mx-1">Predict Price</span> 
            to see the valuation and market insights.
          </p>
        </div>
      </div>
    );
  }

  // Car Overview Data Config
  const overviewItems = [
    { icon: <Car size={18} />, label: "Model", value: currentCar.model },
    { icon: <Calendar size={18} />, label: "Registration Year", value: `Jan ${currentCar.year}` },
    { icon: <Shield size={18} />, label: "Insurance", value: currentCar.insurance },
    { icon: <Fuel size={18} />, label: "Fuel Type", value: currentCar.fuelType },
    { icon: <Armchair size={18} />, label: "Seats", value: `${currentCar.seats} Seats` },
    { icon: <Gauge size={18} />, label: "Kms Driven", value: `${currentCar.kmsDriven.toLocaleString()} Kms` },
    { icon: <Building2 size={18} />, label: "RTO", value: currentCar.rto },
    { icon: <User size={18} />, label: "Ownership", value: currentCar.owner },
    { icon: <Link size={18} />, label: "Engine Displacement", value: `${currentCar.engineCC} cc` },
    { icon: <GitGraph size={18} />, label: "Transmission", value: currentCar.transmission },
  ];

  return (
    <div className="flex-1 bg-gray-50 overflow-y-auto p-4 md:p-8">
      
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center gap-3">
          Evaluation Report <span className="text-2xl">📊</span>
        </h2>
        <p className="text-gray-500 mt-2">
          AI-Powered analysis based on current market trends for 
          <span className="font-semibold text-indigo-600 mx-1">{currentCar.brand} {currentCar.model}</span> 
          vehicles.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        
        {/* Main Prediction Card */}
        <div className="lg:col-span-1 bg-white rounded-2xl shadow-sm border border-indigo-100 p-6 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-bl-full -mr-8 -mt-8 z-0"></div>
          <div className="relative z-10">
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-2">Estimated Market Value</h3>
            <div className="flex flex-col gap-1">
              <span className="text-4xl xl:text-5xl font-extrabold text-indigo-600 tracking-tight">
                {formatCurrency(predictedPrice)}
              </span>
              <span className="inline-block w-fit text-xs text-green-700 font-bold bg-green-100 px-2 py-1 rounded-full">
                95% Confidence Interval
              </span>
            </div>
          </div>
          <div className="mt-6 pt-6 border-t border-gray-100 relative z-10">
            <p className="text-sm text-gray-500 leading-relaxed">
              This valuation assumes the vehicle is in good condition. Actual price may vary based on physical inspection.
            </p>
          </div>
        </div>

        {/* Car Overview Card (Matches User Image) */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Car Overview</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-y-6 gap-x-8">
            {overviewItems.map((item, index) => (
              <div key={index} className="flex items-start gap-4">
                <div className="text-gray-400 mt-0.5">
                  {item.icon}
                </div>
                <div>
                  <p className="text-sm text-gray-400 font-medium mb-0.5">{item.label}</p>
                  <p className="text-base font-medium text-gray-800">{item.value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Insight 1: Price vs Market Scatter */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
              <BarChart3 size={20} />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Price vs. Market</h3>
              <p className="text-xs text-gray-500">Comparison with {filteredMarketData.length} similar {currentCar.brand} listings</p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis 
                  type="number" 
                  dataKey="kmsDriven" 
                  name="Distance" 
                  unit="km" 
                  tick={{fontSize: 12, fill: '#6B7280'}} 
                  tickFormatter={(val) => `${val/1000}k`}
                />
                <YAxis 
                  type="number" 
                  dataKey="price" 
                  name="Price" 
                  unit="" 
                  tick={{fontSize: 12, fill: '#6B7280'}}
                  tickFormatter={(val) => `₹${val/1000}k`} 
                />
                <Tooltip 
                  cursor={{ strokeDasharray: '3 3' }} 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-gray-800 text-white text-xs p-2 rounded shadow-lg">
                          <p className="font-semibold">{data.brand} {data.model}</p>
                          <p>Year: {data.year}</p>
                          <p>Price: {formatCurrency(data.price)}</p>
                          <p>Kms: {data.kmsDriven.toLocaleString()} km</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend />
                <Scatter name="Market Data" data={filteredMarketData} fill="#9CA3AF" fillOpacity={0.6} shape="circle" />
                <Scatter name="Your Car" data={[currentCar]} fill="#4F46E5" shape="star" r={10} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Insight 2: Depreciation Trend Line */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
           <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-red-100 rounded-lg text-red-600">
              <TrendingDown size={20} />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Depreciation Forecast</h3>
              <p className="text-xs text-gray-500">Projected value over next 5 years</p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={depreciationTrend} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="year" tick={{fontSize: 12, fill: '#6B7280'}} />
                <YAxis tick={{fontSize: 12, fill: '#6B7280'}} tickFormatter={(val) => `₹${val/1000}k`} />
                <Tooltip 
                   contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                   formatter={(val: number) => formatCurrency(val)}
                />
                <Line 
                  type="monotone" 
                  dataKey="price" 
                  stroke="#EF4444" 
                  strokeWidth={3} 
                  dot={{ r: 4, fill: '#EF4444' }} 
                  activeDot={{ r: 8 }} 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Insight 3: Feature Importance Bar */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 lg:col-span-2">
           <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-purple-100 rounded-lg text-purple-600">
              <LineIcon size={20} />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Valuation Factors</h3>
              <p className="text-xs text-gray-500">Key contributors to the predicted price</p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={featureImportance}
                margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#E5E7EB" />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="feature" 
                  type="category" 
                  width={140} 
                  tick={{fontSize: 12, fill: '#374151', fontWeight: 500}} 
                />
                <Tooltip 
                  cursor={{fill: 'transparent'}}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  formatter={(val: number) => `${(val * 100).toFixed(0)}% Impact`}
                />
                <Bar dataKey="importance" radius={[0, 4, 4, 0]} barSize={30}>
                  {featureImportance.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={['#4F46E5', '#6366F1', '#818CF8', '#A5B4FC', '#C7D2FE', '#E0E7FF', '#F3F4F6', '#F9FAFB'][index % 8]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
};