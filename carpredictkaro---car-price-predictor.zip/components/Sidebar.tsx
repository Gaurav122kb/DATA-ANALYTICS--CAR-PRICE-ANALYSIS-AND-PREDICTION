import React, { useEffect } from 'react';
import { Brand, FuelType, Transmission, PredictionInput, Owner, Insurance } from '../types';
import { CAR_DATABASE } from '../services/carService';
import { CarFront, Filter } from 'lucide-react';

interface SidebarProps {
  inputs: PredictionInput;
  setInputs: React.Dispatch<React.SetStateAction<PredictionInput>>;
  onPredict: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ inputs, setInputs, onPredict }) => {
  
  const handleInputChange = (field: keyof PredictionInput, value: any) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  // When brand changes, reset model to first available
  const handleBrandChange = (brand: Brand) => {
    const firstModel = CAR_DATABASE[brand][0].name;
    // Also reset year if it's invalid for the new model
    const releaseYear = CAR_DATABASE[brand][0].releaseYear;
    const newYear = Math.max(inputs.year, releaseYear);

    setInputs(prev => ({
      ...prev,
      brand: brand,
      model: firstModel,
      year: newYear
    }));
  };

  // Get current model info to limit year slider
  const currentModelInfo = CAR_DATABASE[inputs.brand].find(m => m.name === inputs.model) || CAR_DATABASE[inputs.brand][0];
  const minYear = currentModelInfo.releaseYear;

  // Auto-correct year if model changes and current year is too old
  useEffect(() => {
    if (inputs.year < minYear) {
      setInputs(prev => ({ ...prev, year: minYear }));
    }
  }, [inputs.model, minYear, inputs.year, setInputs]);


  return (
    <div className="w-full lg:w-80 bg-white border-r border-gray-200 h-full p-6 flex flex-col shadow-sm overflow-y-auto z-10 relative">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 bg-indigo-600 rounded-lg">
          <CarFront className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-xl font-bold text-gray-800 leading-tight">
          CarPredict<span className="text-indigo-600">Karo</span>
        </h1>
      </div>

      <div className="flex items-center gap-2 mb-6 text-gray-500 uppercase text-xs font-semibold tracking-wider">
        <Filter className="w-4 h-4" />
        <span>Vehicle Configuration</span>
      </div>

      <div className="space-y-5 flex-1 pb-4">
        
        {/* Brand */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-600 uppercase">Make / Brand</label>
          <select 
            className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm"
            value={inputs.brand}
            onChange={(e) => handleBrandChange(e.target.value as Brand)}
          >
            {Object.values(Brand).map((b) => <option key={b} value={b}>{b}</option>)}
          </select>
        </div>

        {/* Model Selection */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-600 uppercase">Model</label>
          <select 
            className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm"
            value={inputs.model}
            onChange={(e) => handleInputChange('model', e.target.value)}
          >
            {CAR_DATABASE[inputs.brand].map((m) => (
              <option key={m.name} value={m.name}>{m.name}</option>
            ))}
          </select>
          <p className="text-[10px] text-gray-400 text-right">Released in {minYear}</p>
        </div>

        {/* Year */}
        <div className="space-y-1.5">
          <div className="flex justify-between">
            <label className="text-xs font-semibold text-gray-600 uppercase">Year</label>
            <span className="text-xs font-bold text-indigo-600">{inputs.year}</span>
          </div>
          <input 
            type="range" min={minYear} max="2025" step="1"
            value={inputs.year}
            onChange={(e) => handleInputChange('year', parseInt(e.target.value))}
            className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
           <div className="flex justify-between text-[10px] text-gray-400">
            <span>{minYear}</span>
            <span>2025</span>
          </div>
        </div>

        {/* Kms Driven */}
        <div className="space-y-1.5">
           <div className="flex justify-between">
            <label className="text-xs font-semibold text-gray-600 uppercase">Distance</label>
            <span className="text-xs font-bold text-indigo-600">{(inputs.kmsDriven/1000).toFixed(0)}k km</span>
          </div>
          <input 
            type="range" min="5000" max="150000" step="1000"
            value={inputs.kmsDriven}
            onChange={(e) => handleInputChange('kmsDriven', parseInt(e.target.value))}
            className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
        </div>

        {/* Fuel & Transmission Row */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-600 uppercase">Fuel</label>
            <select 
              className="w-full px-2 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
              value={inputs.fuelType}
              onChange={(e) => handleInputChange('fuelType', e.target.value)}
            >
              {Object.values(FuelType).map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-600 uppercase">Gearbox</label>
            <select 
              className="w-full px-2 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
              value={inputs.transmission}
              onChange={(e) => handleInputChange('transmission', e.target.value)}
            >
              {Object.values(Transmission).map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>

        {/* Ownership */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-600 uppercase">Ownership</label>
          <select 
            className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
            value={inputs.owner}
            onChange={(e) => handleInputChange('owner', e.target.value)}
          >
            {Object.values(Owner).map((o) => <option key={o} value={o}>{o}</option>)}
          </select>
        </div>

         {/* Engine CC & Seats Row */}
         <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-600 uppercase">Engine (CC)</label>
            <input 
              type="number"
              min="0" max="5000" step="100"
              className="w-full px-2 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
              value={inputs.engineCC}
              onChange={(e) => handleInputChange('engineCC', parseInt(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-600 uppercase">Seats</label>
            <select 
              className="w-full px-2 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
              value={inputs.seats}
              onChange={(e) => handleInputChange('seats', parseInt(e.target.value))}
            >
              <option value={2}>2 Seats</option>
              <option value={4}>4 Seats</option>
              <option value={5}>5 Seats</option>
              <option value={7}>7 Seats</option>
            </select>
          </div>
        </div>

        {/* Insurance */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-600 uppercase">Insurance</label>
          <select 
            className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
            value={inputs.insurance}
            onChange={(e) => handleInputChange('insurance', e.target.value)}
          >
            {Object.values(Insurance).map((i) => <option key={i} value={i}>{i}</option>)}
          </select>
        </div>

        {/* RTO */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-600 uppercase">RTO Location</label>
          <input 
             type="text"
             className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm"
             value={inputs.rto}
             onChange={(e) => handleInputChange('rto', e.target.value)}
             placeholder="e.g. New Delhi"
          />
        </div>

      </div>

      <div className="pt-4 mt-4 border-t border-gray-200">
        <button 
          onClick={onPredict}
          className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transform transition-all active:scale-95 flex justify-center items-center gap-2"
        >
          <span>Predict Price</span>
          <span className="text-lg">🚀</span>
        </button>
      </div>
    </div>
  );
};